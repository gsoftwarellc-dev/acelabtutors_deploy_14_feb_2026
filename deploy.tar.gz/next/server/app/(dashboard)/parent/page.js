(()=>{var e={};e.id=7662,e.ids=[7662],e.modules={72934:e=>{"use strict";e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{"use strict";e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{"use strict";e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},55315:e=>{"use strict";e.exports=require("path")},17360:e=>{"use strict";e.exports=require("url")},57335:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>l.a,__next_app__:()=>h,originalPathname:()=>p,pages:()=>c,routeModule:()=>u,tree:()=>d}),s(46243),s(6989),s(35866),s(41116);var a=s(23191),r=s(88716),i=s(37922),l=s.n(i),o=s(95231),n={};for(let e in o)0>["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(e)&&(n[e]=()=>o[e]);s.d(t,n);let d=["",{children:["(dashboard)",{children:["parent",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,46243)),"/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/(dashboard)/parent/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(s.bind(s,6989)),"/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/(dashboard)/layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,35866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,73881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,41116)),"/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/layout.tsx"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,35866,23)),"next/dist/client/components/not-found-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,73881))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],c=["/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/(dashboard)/parent/page.tsx"],p="/(dashboard)/parent/page",h={require:s,loadChunk:()=>Promise.resolve()},u=new a.AppPageRouteModule({definition:{kind:r.x.APP_PAGE,page:"/(dashboard)/parent/page",pathname:"/parent",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:d}})},46866:(e,t,s)=>{Promise.resolve().then(s.bind(s,67311))},70985:(e,t,s)=>{Promise.resolve().then(s.bind(s,37287))},6507:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("bell",[["path",{d:"M10.268 21a2 2 0 0 0 3.464 0",key:"vwvbt9"}],["path",{d:"M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326",key:"11g9vi"}]])},52807:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("book-copy",[["path",{d:"M5 7a2 2 0 0 0-2 2v11",key:"1yhqjt"}],["path",{d:"M5.803 18H5a2 2 0 0 0 0 4h9.5a.5.5 0 0 0 .5-.5V21",key:"edzzo5"}],["path",{d:"M9 15V4a2 2 0 0 1 2-2h9.5a.5.5 0 0 1 .5.5v14a.5.5 0 0 1-.5.5H11a2 2 0 0 1 0-4h10",key:"1nwzrg"}]])},6343:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("book-open",[["path",{d:"M12 7v14",key:"1akyts"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z",key:"ruj8y"}]])},80239:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("chart-no-axes-column-increasing",[["path",{d:"M5 21v-6",key:"1hz6c0"}],["path",{d:"M12 21V9",key:"uvy0l4"}],["path",{d:"M19 21V3",key:"11j9sm"}]])},44765:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("contact",[["path",{d:"M16 2v2",key:"scm5qe"}],["path",{d:"M7 22v-2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v2",key:"1waht3"}],["path",{d:"M8 2v2",key:"pbkmx"}],["circle",{cx:"12",cy:"11",r:"3",key:"itu57m"}],["rect",{x:"3",y:"4",width:"18",height:"18",rx:"2",key:"12vinp"}]])},28916:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("credit-card",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},36283:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("file-text",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},69561:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("funnel",[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",key:"sc7q7i"}]])},70717:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("history",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}],["path",{d:"M12 7v5l4 2",key:"1fdv2h"}]])},24319:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("layout-dashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},71810:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("log-out",[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]])},40617:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("message-square",[["path",{d:"M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z",key:"18887p"}]])},88307:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]])},61521:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("sliders-horizontal",[["path",{d:"M10 5H3",key:"1qgfaw"}],["path",{d:"M12 19H3",key:"yhmn1j"}],["path",{d:"M14 3v4",key:"1sua03"}],["path",{d:"M16 17v4",key:"1q0r14"}],["path",{d:"M21 12h-9",key:"1o4lsq"}],["path",{d:"M21 19h-5",key:"1rlt1p"}],["path",{d:"M21 5h-7",key:"1oszz2"}],["path",{d:"M8 10v4",key:"tgpxqk"}],["path",{d:"M8 12H3",key:"a7s4jb"}]])},24061:(e,t,s)=>{"use strict";s.d(t,{Z:()=>a});let a=(0,s(25578).Z)("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]])},67311:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>M});var a=s(10326),r=s(35047),i=s(90434),l=s(68136),o=s(51223),n=s(17577),d=s(24319),c=s(6343),p=s(36283),h=s(40617),u=s(79635),m=s(70717),x=s(28916),f=s(24061),y=s(44765),b=s(61521),g=s(52807),v=s(69561),j=s(80239),w=s(71810);function k({role:e}){let t=(0,r.usePathname)(),{logout:s}=(0,l.a)(),[k,N]=(0,n.useState)(0),Z={student:[{href:"/student",label:"Dashboard",icon:d.Z},{href:"/student/courses",label:"My Courses",icon:c.Z},{href:"/student/exams",label:"Exams & Result",icon:p.Z},{href:"/student/messages",label:"Messages",icon:h.Z},{href:"/student/profile",label:"Profile",icon:u.Z}],parent:[{href:"/parent",label:"Overview",icon:d.Z},{href:"/parent/messages",label:"Messages",icon:h.Z},{href:"/parent/profile",label:"Profile",icon:u.Z}],tutor:[{href:"/tutor",label:"Dashboard",icon:d.Z},{href:"/tutor/courses",label:"Courses",icon:c.Z},{href:"/tutor/attendance-history",label:"Attendance History",icon:m.Z},{href:"/tutor/messages",label:"Messages",icon:h.Z},{href:"/tutor/earnings",label:"Earnings",icon:x.Z},{href:"/tutor/profile",label:"Profile",icon:u.Z}],admin:[{href:"/admin",label:"Overview",icon:d.Z},{href:"/admin/users",label:"User Management",icon:f.Z},{href:"/admin/messages",label:"Messages",icon:h.Z},{href:"/admin/contacts",label:"Contacts",icon:y.Z},{href:"/admin/finance",label:"Finance",icon:x.Z},{href:"/admin/courses/control",label:"Control Courses",icon:b.Z},{href:"/admin/registrations",label:"Registrations",icon:m.Z},{href:"/admin/enrollment",label:"Course Enrollment",icon:g.Z},{href:"/admin/filters",label:"Manage Filters",icon:v.Z},{href:"/admin/performance",label:"Performance",icon:j.Z},{href:"/admin/profile",label:"Profile",icon:u.Z}]},M=Z[e]||Z.student;return(0,a.jsxs)("div",{className:"w-64 bg-white border-r h-screen hidden md:flex flex-col fixed left-0 top-0",children:[a.jsx("div",{className:"p-6 border-b",children:a.jsx(i.default,{href:"/",className:"flex items-center justify-center w-full",children:a.jsx("img",{src:"/logo_main.png",alt:"Acelab",className:"h-20 w-auto object-contain"})})}),a.jsx("nav",{className:"flex-1 p-4 space-y-1 overflow-y-auto",children:M.map(e=>{let s=e.icon,r=t===e.href;return(0,a.jsxs)(i.default,{href:e.href,className:(0,o.cn)("flex items-center space-x-3 px-4 py-3 text-sm font-medium rounded-lg transition-colors",r?"bg-primary/10 text-primary":"text-slate-600 hover:bg-slate-50 hover:text-slate-900"),children:[a.jsx(s,{size:18}),a.jsx("span",{children:e.label}),"Messages"===e.label&&k>0&&a.jsx("span",{className:"ml-auto bg-red-500 text-white text-xs font-bold rounded-full px-2 py-0.5 min-w-[20px] text-center",children:k})]},e.href)})}),a.jsx("div",{className:"p-4 border-t",children:(0,a.jsxs)("button",{type:"button",onClick:()=>s(),className:"flex items-center space-x-3 w-full px-4 py-3 text-sm font-medium text-red-500 hover:bg-red-50 rounded-lg transition-colors text-left",children:[a.jsx(w.Z,{size:18}),a.jsx("span",{children:"Sign Out"})]})})]})}var N=s(6507);function Z({role:e}){let{user:t}=(0,l.a)();return(0,a.jsxs)("header",{className:"h-16 bg-white border-b flex items-center justify-between px-6 sticky top-0 z-10",children:[(0,a.jsxs)("h2",{className:"text-lg font-semibold text-slate-800 capitalize",children:[e," Dashboard ",(0,a.jsxs)("span",{className:"text-slate-900 font-medium text-sm ml-2",children:["ID: ",t?.id]})]}),(0,a.jsxs)("div",{className:"flex items-center space-x-4",children:[(0,a.jsxs)("button",{className:"p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-50 relative",children:[a.jsx(N.Z,{size:20}),a.jsx("span",{className:"absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-white"})]}),(0,a.jsxs)("div",{className:"flex items-center space-x-3 pl-4 border-l",children:[(0,a.jsxs)("div",{className:"text-right hidden sm:block",children:[a.jsx("p",{className:"text-sm font-medium text-slate-900",children:t?.name||"User"}),(0,a.jsxs)("p",{className:"text-xs text-slate-500 capitalize",children:["ID: ",t?.id," • ",t?.role||e]})]}),a.jsx("div",{className:"h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-bold text-sm overflow-hidden",children:t?.avatar?a.jsx("img",{src:`https://api.acelabtutors.co.uk${t.avatar}`,alt:t.name,className:"h-full w-full object-cover"}):a.jsx("span",{children:(t?.name||"").split(" ").map(e=>e[0]).join("").toUpperCase().slice(0,2)})})]})]})]})}function M({children:e}){let t=(0,r.usePathname)().split("/")[1];return(0,a.jsxs)("div",{className:"min-h-screen bg-slate-50",children:[a.jsx(k,{role:t}),(0,a.jsxs)("div",{className:"md:ml-64 min-h-screen flex flex-col",children:[a.jsx(Z,{role:t}),a.jsx("main",{className:"flex-1 p-6",children:e})]})]})}},37287:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>ee});var a,r=s(10326),i=s(17577),l=s(91664),o=s(41190),n=s(88307),d=s(79635),c=s(6343),p=s(70717);let h=(0,s(25578).Z)("user-check",[["path",{d:"m16 11 2 2 4-4",key:"9rsbq5"}],["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]]);var u=s(29752),m=s(18069);let x={data:""},f=e=>{if("object"==typeof window){let t=(e?e.querySelector("#_goober"):window._goober)||Object.assign(document.createElement("style"),{innerHTML:" ",id:"_goober"});return t.nonce=window.__nonce__,t.parentNode||(e||document.head).appendChild(t),t.firstChild}return e||x},y=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,b=/\/\*[^]*?\*\/|  +/g,g=/\n+/g,v=(e,t)=>{let s="",a="",r="";for(let i in e){let l=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+l+";":a+="f"==i[1]?v(l,i):i+"{"+v(l,"k"==i[1]?"":t)+"}":"object"==typeof l?a+=v(l,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=l&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),r+=v.p?v.p(i,l):i+":"+l+";")}return s+(t&&r?t+"{"+r+"}":r)+a},j={},w=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+w(e[s]);return t}return e},k=(e,t,s,a,r)=>{let i=w(e),l=j[i]||(j[i]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(i));if(!j[l]){let t=i!==e?e:(e=>{let t,s,a=[{}];for(;t=y.exec(e.replace(b,""));)t[4]?a.shift():t[3]?(s=t[3].replace(g," ").trim(),a.unshift(a[0][s]=a[0][s]||{})):a[0][t[1]]=t[2].replace(g," ").trim();return a[0]})(e);j[l]=v(r?{["@keyframes "+l]:t}:t,s?"":"."+l)}let o=s&&j.g?j.g:null;return s&&(j.g=j[l]),((e,t,s,a)=>{a?t.data=t.data.replace(a,e):-1===t.data.indexOf(e)&&(t.data=s?e+t.data:t.data+e)})(j[l],t,a,o),l},N=(e,t,s)=>e.reduce((e,a,r)=>{let i=t[r];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":v(e,""):!1===e?"":e}return e+a+(null==i?"":i)},"");function Z(e){let t=this||{},s=e.call?e(t.p):e;return k(s.unshift?s.raw?N(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,f(t.target),t.g,t.o,t.k)}Z.bind({g:1});let M,z,P,_=Z.bind({k:1});function C(e,t){let s=this||{};return function(){let a=arguments;function r(i,l){let o=Object.assign({},i),n=o.className||r.className;s.p=Object.assign({theme:z&&z()},o),s.o=/ *go\d+/.test(n),o.className=Z.apply(s,a)+(n?" "+n:""),t&&(o.ref=l);let d=e;return e[0]&&(d=o.as||e,delete o.as),P&&d[0]&&P(o),M(d,o)}return t?t(r):r}}var S=e=>"function"==typeof e,D=(e,t)=>S(e)?e(t):e,$=(()=>{let e=0;return()=>(++e).toString()})(),A=((()=>{let e;return()=>e})(),"default"),q=(e,t)=>{let{toastLimit:s}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,s)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return q(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},H=[],E={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},O={},I=(e,t=A)=>{O[t]=q(O[t]||E,e),H.forEach(([e,s])=>{e===t&&s(O[t])})},U=e=>Object.keys(O).forEach(t=>I(e,t)),F=e=>Object.keys(O).find(t=>O[t].toasts.some(t=>t.id===e)),R=(e=A)=>t=>{I(t,e)},L={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},T=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||$()}),V=e=>(t,s)=>{let a=T(t,e,s);return R(a.toasterId||F(a.id))({type:2,toast:a}),a.id},G=(e,t)=>V("blank")(e,t);G.error=V("error"),G.success=V("success"),G.loading=V("loading"),G.custom=V("custom"),G.dismiss=(e,t)=>{let s={type:3,toastId:e};t?R(t)(s):U(s)},G.dismissAll=e=>G.dismiss(void 0,e),G.remove=(e,t)=>{let s={type:4,toastId:e};t?R(t)(s):U(s)},G.removeAll=e=>G.remove(void 0,e),G.promise=(e,t,s)=>{let a=G.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let r=t.success?D(t.success,e):void 0;return r?G.success(r,{id:a,...s,...null==s?void 0:s.success}):G.dismiss(a),e}).catch(e=>{let r=t.error?D(t.error,e):void 0;r?G.error(r,{id:a,...s,...null==s?void 0:s.error}):G.dismiss(a)}),e};var J=_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,Y=_`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,B=_`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,W=(C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${J} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${Y} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${B} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,_`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),X=(C("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${W} 1s linear infinite;
`,_`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),K=_`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,Q=(C("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${X} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${K} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,C("div")`
  position: absolute;
`,C("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,_`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);function ee(){let[e,t]=(0,i.useState)(""),[s,a]=(0,i.useState)(!1),[x,f]=(0,i.useState)(null),[y,b]=(0,i.useState)(!1),g=async t=>{if(t.preventDefault(),e.trim()){a(!0),b(!0),f(null);try{let{data:t}=await m.Z.post("/parent/search-child",{student_id:e});f(t)}catch(e){console.error("Search failed:",e),e.response?.status===404?G.error("Student not found with this ID"):G.error("Failed to search. Please try again.")}finally{a(!1)}}};return(0,r.jsxs)("div",{className:"space-y-8 max-w-5xl mx-auto",children:[(0,r.jsxs)("div",{className:"text-center space-y-2",children:[r.jsx("h1",{className:"text-3xl font-bold text-slate-800",children:"Find Your Child's Progress"}),r.jsx("p",{className:"text-slate-500",children:"Enter your child's Student ID to view their performance and classes."})]}),r.jsx(u.Zb,{className:"max-w-xl mx-auto border-blue-100 shadow-md",children:r.jsx(u.aY,{className:"p-6",children:(0,r.jsxs)("form",{onSubmit:g,className:"flex gap-4",children:[(0,r.jsxs)("div",{className:"relative flex-1",children:[r.jsx(n.Z,{className:"absolute left-3 top-1/2 -translate-y-1/2 text-slate-400",size:20}),r.jsx(o.I,{placeholder:"Enter Student ID (e.g., 25)",className:"pl-10 h-12 text-lg",value:e,onChange:e=>t(e.target.value)})]}),r.jsx(l.z,{type:"submit",size:"lg",className:"h-12 px-8",disabled:s,children:s?"Searching...":"Search"})]})})}),x&&(0,r.jsxs)("div",{className:"space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500",children:[(0,r.jsxs)("div",{className:"bg-white rounded-xl border border-slate-200 shadow-sm p-6 flex items-center gap-6",children:[r.jsx("div",{className:"h-20 w-20 bg-primary/10 rounded-full flex items-center justify-center text-primary",children:r.jsx(d.Z,{size:40})}),(0,r.jsxs)("div",{children:[r.jsx("h2",{className:"text-2xl font-bold text-slate-900",children:x.student.name}),(0,r.jsxs)("p",{className:"text-slate-500",children:["Student ID: ",r.jsx("span",{className:"font-mono font-medium text-slate-700",children:x.student.id})]}),(0,r.jsxs)("p",{className:"text-sm text-slate-400",children:["Joined ",x.student.joined_at]})]})]}),(0,r.jsxs)("div",{children:[(0,r.jsxs)("h3",{className:"text-xl font-semibold text-slate-800 mb-4 flex items-center",children:[r.jsx(c.Z,{className:"mr-2 text-primary",size:24}),"Enrolled Courses"]}),r.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 gap-6",children:x.enrollments.map(e=>(0,r.jsxs)(u.Zb,{className:"hover:shadow-md transition-all border-slate-200",children:[r.jsx("div",{className:"h-2 bg-primary w-full rounded-t-xl"}),(0,r.jsxs)(u.Ol,{className:"pb-4",children:[(0,r.jsxs)(u.ll,{className:"text-lg flex justify-between items-start",children:[r.jsx("span",{children:e.course_name}),r.jsx("span",{className:"text-xs font-normal px-2 py-1 bg-blue-50 text-blue-700 rounded-full capitalize",children:e.status})]}),(0,r.jsxs)("p",{className:"text-sm text-slate-500",children:["Tutor: ",e.tutor_name]})]})]},e.course_id))})]}),(0,r.jsxs)("div",{className:"bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden",children:[r.jsx("div",{className:"bg-slate-50 px-6 py-4 border-b border-slate-200",children:(0,r.jsxs)("h3",{className:"text-xl font-semibold text-slate-800 flex items-center",children:[r.jsx(p.Z,{className:"mr-2 text-primary",size:24}),"Class History"]})}),r.jsx("div",{className:"divide-y divide-slate-100",children:x.class_history.length>0?x.class_history.map(e=>(0,r.jsxs)("div",{className:"px-6 py-4 flex items-center justify-between hover:bg-slate-50/50 transition-colors",children:[(0,r.jsxs)("div",{className:"flex items-center gap-4",children:[r.jsx("div",{className:"bg-blue-50 text-blue-600 p-2 rounded-lg",children:r.jsx(p.Z,{size:18})}),(0,r.jsxs)("div",{children:[r.jsx("p",{className:"font-semibold text-slate-900",children:e.course_name}),r.jsx("p",{className:"text-sm text-slate-500",children:new Date(e.date).toLocaleDateString("en-GB",{day:"numeric",month:"long",year:"numeric"})})]})]}),r.jsx("div",{className:"flex items-center gap-2",children:r.jsx("span",{className:`px-3 py-1 rounded-full text-xs font-medium ${"present"===e.status?"bg-green-100 text-green-700":"bg-red-100 text-red-700"}`,children:e.status.toUpperCase()})})]},e.id)):r.jsx("div",{className:"p-12 text-center text-slate-400",children:r.jsx("p",{children:"No class history recorded yet."})})})]})]}),y&&!x&&!s&&(0,r.jsxs)("div",{className:"text-center py-12 text-slate-500",children:[r.jsx(h,{className:"mx-auto h-12 w-12 text-slate-300 mb-4"}),r.jsx("p",{className:"text-lg",children:"No student found."}),r.jsx("p",{className:"text-sm",children:"Please check the Student ID and try again."})]})]})}C("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${Q} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,C("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,C("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,a=i.createElement,v.p=void 0,M=a,z=void 0,P=void 0,Z`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`},29752:(e,t,s)=>{"use strict";s.d(t,{Ol:()=>o,Zb:()=>l,aY:()=>d,ll:()=>n});var a=s(10326),r=s(17577),i=s(51223);let l=r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("rounded-xl border bg-card text-card-foreground shadow",e),...t}));l.displayName="Card";let o=r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("flex flex-col space-y-1.5 p-6",e),...t}));o.displayName="CardHeader";let n=r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("font-semibold leading-none tracking-tight",e),...t}));n.displayName="CardTitle",r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("text-sm text-muted-foreground",e),...t})).displayName="CardDescription";let d=r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("p-6 pt-0",e),...t}));d.displayName="CardContent",r.forwardRef(({className:e,...t},s)=>a.jsx("div",{ref:s,className:(0,i.cn)("flex items-center p-6 pt-0",e),...t})).displayName="CardFooter"},18069:(e,t,s)=>{"use strict";s.d(t,{Z:()=>i});let a=()=>{let e="https://api.acelabtutors.co.uk";return e.endsWith("/api")?e:`${e}/api`},r=()=>({"Content-Type":"application/json",Authorization:"",Accept:"application/json"}),i={get:async e=>{let t=await fetch(`${a()}${e}`,{headers:r()});if(204===t.status)return{data:{}};let s=await t.json();if(!t.ok)throw{response:{data:s,status:t.status}};return{data:s}},post:async(e,t)=>{let s=await fetch(`${a()}${e}`,{method:"POST",headers:r(),body:JSON.stringify(t)});if(204===s.status)return{data:{}};let i=await s.json();if(!s.ok)throw{response:{data:i,status:s.status}};return{data:i}},put:async(e,t)=>{let s=await fetch(`${a()}${e}`,{method:"PUT",headers:r(),body:t?JSON.stringify(t):void 0});if(204===s.status)return{data:{}};let i=await s.json();if(!s.ok)throw{response:{data:i,status:s.status}};return{data:i}},delete:async(e,t)=>{let s=await fetch(`${a()}${e}`,{method:"DELETE",headers:r(),body:t?.data?JSON.stringify(t.data):void 0});if(204===s.status)return{data:{}};let i=await s.json();if(!s.ok)throw{response:{data:i,status:s.status}};return{data:i}}}},6989:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});let a=(0,s(68570).createProxy)(String.raw`/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/(dashboard)/layout.tsx#default`)},46243:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});let a=(0,s(68570).createProxy)(String.raw`/Users/riyadulislamriyadh/Desktop/acelabtutors/frontend/src/app/(dashboard)/parent/page.tsx#default`)},73881:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>r});var a=s(66621);let r=e=>[{type:"image/x-icon",sizes:"16x16",url:(0,a.fillMetadataSegment)(".",e.params,"favicon.ico")+""}]}};var t=require("../../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),a=t.X(0,[8948,416,6621,9513],()=>s(57335));module.exports=a})();